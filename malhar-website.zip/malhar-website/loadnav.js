if(performance.navigation.type == 2)
{
    window.location = "./index.html";
}